﻿

function showADDPpsition() {
    var view = document.getElementById('ContentPlaceHolder1_pnlPosition');
    if (view.style.display == "none") {
        view.style.display = "block";
        view1.value = "Hide";
    }
    else {
        view.style.display = "none";
        view1.value = "Show";
    }
}
function showADDContact() {
    var view = document.getElementById('ContentPlaceHolder1_pnlContact');
    if (view.style.display == "none") {
        view.style.display = "block";
        view1.value = "Hide";
    }
    else {
        view.style.display = "none";
        view1.value = "Show";
    }
}
function showADDCompany() {
    var view = document.getElementById('ContentPlaceHolder1_pnlCompany');
    if (view.style.display == "none") {
        view.style.display = "block";
        view1.value = "Hide";
    }
    else {
        view.style.display = "none";
        view1.value = "Show";
    }
}
